import cv2
import face_recognition
from face_recognition.api import face_encodings, face_locations
import numpy

imgElon=face_recognition.load_image_file('ImageBasic/Elon Musk.jpg')
imgElon=cv2.cvtColor(imgElon,cv2.COLOR_BGR2RGB)
imgTest=face_recognition.load_image_file('ImageBasic/Elon Musk.jpg')
imgTest=cv2.cvtColor(imgTest,cv2.COLOR_BGR2RGB)

faceloc=face_recognition.face_locations(imgElon)[0]
encodeElan=face_recognition.face_encodings(imgElon)[0]
cv2.rectangle(imgElon,(faceloc[3],faceloc[0]),(faceloc[1],faceloc[2]),(255,0,255),2)

faceTest=face_recognition.face_locations(imgTest)[0]
encodeTest=face_recognition.face_encodings(imgTest)[0]
cv2.rectangle(imgTest,(faceTest[3],faceTest[0]),(faceTest[1],faceTest[2]),(255,0,255),2)

results=face_recognition.compare_faces([encodeElan],encodeTest)
faceDis=face_recognition.face_distance([encodeElan],encodeTest)
print(results,faceDis)
cv2.putText(imgTest,f'{results} {round(faceDis[0],2)}',(50,50),cv2.FONT_HERSHEY_COMPLEX,1,(0,0,255),2)

cv2.imshow('Elon Musk',imgElon)
cv2.imshow('Elon Test',imgTest)
cv2.waitKey(0)